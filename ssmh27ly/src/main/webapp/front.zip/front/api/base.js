﻿const base = {
    url : "http://localhost:8080/ssmh27ly/"
}
export default base
